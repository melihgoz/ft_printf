#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>

int sum(int count, ...)
{
	va_list args;
	va_start(args, count);

	int i;
	int s = 0;
	for (i = 0; i < count; i++)
	{
		int x = va_arg(args, int);
		s += x;
	}
	va_end(args);
	return s;
}

int sum2(int a, int b, ...)
{
	va_list args;
	va_start(args, a);

	int s = b;
	int x = va_arg(args, int);

	while (x != 0)
	{
		s += x;
		x = va_arg(args, int);
	}
	va_end(args);
	return s;
}

int main()
{
	printf("Sum is: %d\n", sum2(1, 2, 3, 0));
	return 0;
}
