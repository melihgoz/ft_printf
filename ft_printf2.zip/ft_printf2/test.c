#include "ft_printf.h"
#include <stdio.h>

// int anargultest(int count, ...)
// {
// 	int i = 0;
// 	va_list arg;
// 	va_start(arg, count);

// 	while (count > 0)
// 	{
// 		i += va_arg(arg, int);
// 		count--;
// 	}
// 	va_end(arg);
// 	return (i);
// }

int main()
{
	printf("%d",printf("%s\n", "helloemiralid"));
}
